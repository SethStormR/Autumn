Visual Studio Code Spring icon
-----------------------------
Copy the *.png image file to /opt/apps/com.visualstudio.code/files/share/pixmaps