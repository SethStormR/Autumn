Davinci Resolve Spring icons
-----------------------------
Copy all the image files to /opt/resolve/graphics